import os
import discord
from discord.ext import commands, tasks
import asyncio
import random
import aiohttp
import requests
import json
from aiohttp import ClientSession

class roast(commands.Cog):

  def __init__(self, client):
    self.client = client


  @commands.command(aliases=['yo mama','Yo Mama', 'YO MAMA','YOMAMA'])
  async def yomama(self, ctx):

    url = my_secret = os.environ['url']

    my_secret = os.environ['joke_api']

    results = requests.get('https://api.yomomma.info').json()
    content = results['joke']
    await ctx.send(content)
    await ctx.message.delete()


  @commands.command()
  async def insult(self, ctx,* ,member: discord.Member = None):

    request = requests.get('https://evilinsult.com/generate_insult.php?lang=en&type=json').json()
    insultjson = request['insult']

    await ctx.send(f'{member.mention}'+ '**' + insultjson + "**")
    await ctx.message.delete()




  @commands.command()
  async def dark(self, ctx):

    request = requests.get('https://v2.jokeapi.dev/joke/Dark?type=twopart&format=json&lang=en&amount=1').json()
    darkjson = request['setup']
    darkjson2 = request['delivery']

    # request = requests.get('https://v2.jokeapi.dev/joke/Dark?type=onepart&format=json&lang=en&amount=1').json()
    # darkjson = request['joke']

    # await ctx.send(darkjson)

    await ctx.send(f'{darkjson}\n{darkjson2}')






  




def setup(client):
  client.add_cog(roast(client))