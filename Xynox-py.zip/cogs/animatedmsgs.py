import discord
from discord.ext import commands
import asyncio
import random

class animatedmsgs(commands.Cog):

  def __init__(self, client):
    self.client = client

  
  @commands.command()
  async def boom(self, ctx):
    first_mesg = await ctx.send("```THIS MESSAGE WILL SELFDESTRUCT IN 5```")
    list = (
        "```THIS MESSAGE WILL SELFDESTRUCT IN 4```",
        "```THIS MESSAGE WILL SELFDESTRUCT IN 3```",
        "```THIS MESSAGE WILL SELFDESTRUCT IN 2```",
        "```THIS MESSAGE WILL SELFDESTRUCT IN 1```",
        "```THIS MESSAGE WILL SELFDESTRUCT IN 0```",
        "💣",
        "💥",
        )
    for i in list:
        await asyncio.sleep(1)
        await first_mesg.edit(content=i)


  @commands.command()
  async def virus(self, ctx, user: discord.Member = None, *, virus: str = "trojan"):
        user54 = user or ctx.author
        initial_message = await ctx.send(f"``[▓                    ] / {virus}-virus.exe Packing files.``")
        list = (
            f"``[▓▓▓                    ] / {virus}-virus.exe Packing files.``",
            f"``[▓▓▓▓▓▓▓                ] - {virus}-virus.exe Packing files..``",
            f"``[▓▓▓▓▓▓▓▓▓▓▓▓           ] \ {virus}-virus.exe Packing files..``",
            f"``[▓▓▓▓▓▓▓▓▓▓▓▓▓▓         ] | {virus}-virus.exe Packing files..``",
            f"``[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ] / {virus}-virus.exe Packing files..``",
            f"``[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   ] - {virus}-virus.exe Packing files..``",
            f"``[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] \ {virus}-virus.exe Packing files..``",
            f"``Successfully downloaded {virus}-virus.exe``",
            "``Injecting virus.   |``",
            "``Injecting virus..  /``",
            "``Injecting virus... -``",
            f"``Successfully Injected {virus}-virus.exe into {user54.name}``",
            )
        for i in list:
            await asyncio.sleep(1)
            await initial_message.edit(content=i)







  @commands.command()
  async def hack(self,ctx, user: discord.Member = None):
      gender = ["Male", "Female", "Trans", "Other", "Retard"]
      age = str(random.randrange(10, 25))
      height = ['4\'6\"', '4\'7\"', '4\'8\"', '4\'9\"', '4\'10\"', '4\'11\"', '5\'0\"', '5\'1\"', '5\'2\"', '5\'3\"',
                '5\'4\"', '5\'5\"',
                '5\'6\"', '5\'7\"', '5\'8\"', '5\'9\"', '5\'10\"', '5\'11\"', '6\'0\"', '6\'1\"', '6\'2\"', '6\'3\"',
                '6\'4\"', '6\'5\"',
                '6\'6\"', '6\'7\"', '6\'8\"', '6\'9\"', '6\'10\"', '6\'11\"']
      weight = str(random.randrange(60, 300))
      hair_color = ["Black", "Brown", "Blonde", "White", "Gray", "Red"]
      skin_color = ["White", "Pale", "Brown", "Black", "Light-Skin"]
      religion = ["Christian", "Muslim", "Atheist", "Hindu", "Buddhist", "Jewish"]
      sexuality = ["Straight", "Gay", "Homo", "Bi", "Bi-Sexual", "Lesbian", "Pansexual"]
      education = ["High School", "College", "Middle School", "Elementary School", "Pre School",
                  "Retard never went to school LOL"]
      ethnicity = ["White", "African American", "Asian", "Latino", "Latina", "American", "Mexican", "Korean", "Chinese",
                  "Arab", "Italian", "Puerto Rican", "Non-Hispanic", "Russian", "Canadian", "European", "Indian"]
      occupation = ["Retard has no job LOL", "Certified discord retard", "Janitor", "Police Officer", "Teacher",
                    "Cashier", "Clerk", "Waiter", "Waitress", "Grocery Bagger", "Retailer", "Sales-Person", "Artist",
                    "Singer", "Rapper", "Trapper", "Discord Thug", "Gangster", "Discord Packer", "Mechanic", "Carpenter",
                    "Electrician", "Lawyer", "Doctor", "Programmer", "Software Engineer", "Scientist"]
      salary = ["Retard makes no money LOL", "$" + str(random.randrange(0, 1000)), '<$50,000', '<$75,000', "$100,000",
                "$125,000", "$150,000", "$175,000",
                "$200,000+"]
      location = ["Retard lives in his mom's basement LOL", "America", "United States", "Europe", "Poland", "Mexico",
                  "Russia", "Pakistan", "India",
                  "Some random third world country","UAE", "Canada", "Alabama", "Alaska", "Arizona", "Arkansas", "California",
                  "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana",
                  "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan",
                  "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
                  "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
                  "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah",
                  "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]
      email = ["@gmail.com", "@yahoo.com", "@hotmail.com", "@outlook.com", "@protonmail.com", "@disposablemail.com",
              "@aol.com", "@edu.com", "@icloud.com", "@gmx.net", "@yandex.com"]
      dob = f'{random.randrange(1, 13)}/{random.randrange(1, 32)}/{random.randrange(1984, 2021)}'
      name = ['James Charles', "Michael Smith", "Nasir Khan Jan", "Maria Garcia", "Bhola Records", "Maria Rodriguez",
              "Umor Akmol", "Maria Hernandez", "Maria Martinez", "Saad", "Catherine Smoaks", "Azhan Rizwan",
              "Trudie Peasley", "Jannat Mirza", "Jefferey Amon", "Kang Sae Byeok", "Lola Barreiro",
              "Barabara Nuss", "Saang Woo", "Donnell Kuhlmann", "Seong Gi-hun", "Allan Craft",
              "Elvira Lucien", "Angela Black", "Shantelle Lige", "Chassidy Reinhardt", "Adam Delange",
              "Anabel Rini", "Delbert Kruse", "Celeste Baumeister", "Dr.Phil", "Danette Uhler", "Xochitl Parton",
              "Derek Hetrick", "Chasity Hedge", "Antonia Gonsoulin", "Steve Harvey", "Chastity Lazar", "Moeed Asif",
              "Janet Slusser", "Junita Cagle", "Savita Bhabhi", "Lang Schaff", "Kaila Bier", "Ezra Battey",
              "Bart Maddux", "Mumtaz", "Carrie Kimber", "Zack Polite", "Marni Larson", "Justa Spear"]
      phone = f'({random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)})-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}'
      if user is None:
          user = ctx.author
          password = ['password', '123', 'qarisahabporn', user.name + "iscool123", user.name + "isdaddy",
                      "daddy" + user.name, "ilovedick", "i<3discord", "furryporn456", "secret", "123456789", "apple49",
                      "reddildo32", "princess", "dragon", "password1", "fucKmeHaRdeR", "ilovefurries"]
          message = await ctx.send(f"`Hacking {user}...\n`")
          await asyncio.sleep(1)
          await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\n`")
          await asyncio.sleep(1)
          await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\n`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...\nFinalizing life-span dox details\n`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"```Successfully hacked {user}\nName: {random.choice(name)}\nGender: {random.choice(gender)}\nAge: {age}\nHeight: {random.choice(height)}\nWeight: {weight}\nHair Color: {random.choice(hair_color)}\nSkin Color: {random.choice(skin_color)}\nDOB: {dob}\nLocation: {random.choice(location)}\nPhone: {phone}\nE-Mail: {user.name + random.choice(email)}\nPasswords: {random.choices(password, k=3)}\nOccupation: {random.choice(occupation)}\nAnnual Salary: {random.choice(salary)}\nEthnicity: {random.choice(ethnicity)}\nReligion: {random.choice(religion)}\nSexuality: {random.choice(sexuality)}\nEducation: {random.choice(education)}```")
      else:
          password = ['password', '123', 'mypasswordispassword', user.name + "iscool123", user.name + "isdaddy",
                      "daddy" + user.name, "ilovediscord", "i<3discord", "furryporn456", "secret", "123456789", "apple49",
                      "redskins32", "princess", "dragon", "password1", "1q2w3e4r", "ilovefurries"]
          message = await ctx.send(f"`Hacking {user}...\n`")
          await asyncio.sleep(1)
          await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\n`")
          await asyncio.sleep(1)
          await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\n`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...\nFinalizing life-span dox details\n`")
          await asyncio.sleep(1)
          await message.edit(
              content=f"```Successfully hacked {user}\nName: {random.choice(name)}\nGender: {random.choice(gender)}\nAge: {age}\nHeight: {random.choice(height)}\nWeight: {weight}\nHair Color: {random.choice(hair_color)}\nSkin Color: {random.choice(skin_color)}\nDOB: {dob}\nLocation: {random.choice(location)}\nPhone: {phone}\nE-Mail: {user.name + random.choice(email)}\nPasswords: {random.choices(password, k=3)}\nOccupation: {random.choice(occupation)}\nAnnual Salary: {random.choice(salary)}\nEthnicity: {random.choice(ethnicity)}\nReligion: {random.choice(religion)}\nSexuality: {random.choice(sexuality)}\nEducation: {random.choice(education)}```")






def setup(client):
  client.add_cog(animatedmsgs(client))

    