import discord
from discord.ext import commands
import asyncio
import random
import DiscordUtils

class reverse(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command()
  @commands.cooldown(rate=1, per=2, type=commands.BucketType.user)
  async def reverse(self, ctx, *, text: str):

      t_rev = text[::-1].replace("@", "@‎").replace("&", "&‎")
      await ctx.reply(f"🔁 {t_rev}")

def setup(client):
  client.add_cog(reverse(client))
