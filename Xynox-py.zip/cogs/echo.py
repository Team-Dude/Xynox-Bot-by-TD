import discord
from discord.ext import commands
import asyncio
import random
import DiscordUtils

class echo(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command(name='echo',aliases=['ec','e'])
  async def echo(self,ctx, *,message = None):
    message = message or "Please Provide a message to echo..."
    await ctx.message.delete()
    await ctx.send(message)

  @commands.command()
  @commands.is_owner()
  async def paginate(self, ctx):
      embed1 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 1")
      embed2 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 2")
      embed3 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 3")
      paginator = DiscordUtils.Pagination.CustomEmbedPaginator(ctx, remove_reactions=True)
      paginator.add_reaction('⏮️', "first")
      paginator.add_reaction('⏪', "back")
      paginator.add_reaction('🔐', "lock")
      paginator.add_reaction('⏩', "next")
      paginator.add_reaction('⏭️', "last")
      embeds = [embed1, embed2, embed3]
      await paginator.run(embeds)


def setup(client):
  client.add_cog(echo(client))

    