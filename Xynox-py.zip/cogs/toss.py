import discord
from discord.ext import commands
import asyncio
import random
from PIL import Image
from io import BytesIO
from discord_components import *


class toss(commands.Cog):

  def __init__(self, client):
    self.client = client


  @commands.command(name='toss',aliases=['TOSS','t','T'])
  @commands.cooldown(1, 10,commands.BucketType.guild)
  async def toss(self, ctx,* , user:discord.Member= None):
    if user == None:
      user = ctx.author
    #toss pic
    toss = Image.open("toss.png")

    asset = user.avatar_url_as(size=128)
    data = BytesIO(await asset.read())
    pfp = Image.open(data)
    pfp = pfp.resize((97,104))

    toss.paste(pfp,(568,216))
    toss.save("toss.png")
    file=discord.File("toss.png")
    await ctx.send(file=discord.File("toss.png"))



def setup(client):
  client.add_cog(toss(client))

    