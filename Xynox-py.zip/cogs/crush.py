import discord
from discord.ext import commands
import asyncio
import random
from picdata import *
from randompicdata import *

class Games(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command()
  @commands.cooldown(1, 10,commands.BucketType.guild)
  async def crush(self, ctx, user: discord.Member = None):
        user69 = user or ctx.author

        lover2 = [random_killjoy_pic, random_asuka_pic, random_raze_pic, random_jett_pic, random_viper_pic, random_astra_pic, random_chamber_pic, random_jc_pic, random_dl_pic]

        randomlover2 = random.choice(piclist)

        
        embed = discord.Embed(title = f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏',color = 0x262626)
        embed.set_image(url='https://i.imgur.com/WrDDcUr.png')
        msg = await ctx.send(embed=embed)
        embeda = discord.Embed(title='Lover Found!',description=f'\n\t\t{user69.mention} Loves  ',color=0xff0000)
        embeda.set_image(url = f'{randomlover2}')
        
        await asyncio.sleep(2.5)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking █▒▒▒▒▒▒▒▒▒',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking ███▒▒▒▒▒▒▒',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking █████▒▒▒▒▒',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking ███████▒▒▒',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking █████████▒',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title=f'**Welcome To Crush Generator 5000**\nFind ur perfect match 💓💏\n',description='\tMatchmaking ██████████',color = 0x262626))
        await asyncio.sleep(1)
        await msg.edit(embed = discord.Embed(title='MATCH FOUND!!!',description=f'Your Name = {user69.mention}',color=0x262626))
        await asyncio.sleep(1.1)
        await msg.edit(embed = embeda)



def setup(client):
  client.add_cog(Games(client))