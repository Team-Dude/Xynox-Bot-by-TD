import os
import discord
from discord.ext import commands, tasks
import asyncio
import random
import aiohttp
import requests
import json
from aiohttp import ClientSession

class nsfw(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command()
  async def nsfw(self, ctx):
    embed = discord.Embed(title='**NSFW**',description= "U Finally Showed Up Eh 😏", color = 0x666699)
    embed.add_field(name='NSFW Command List', value='• ass \n • 4k \n • anal \n • boobs \n • pussy \n • hentai \n  • milf \n  • gif \n •|| futa|| \n •|| blowjob|| \n')
    await ctx.send(embed=embed)

  @commands.command()
  @commands.is_nsfw()
  async def ass(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=ass')
      assjson = await request.json()

    embed = discord.Embed(title = 'Ass', description = '\n', color = 0x009933)
    embed.set_image(url=assjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()

  
  @commands.command(aliases=['4k'])
  @commands.is_nsfw()
  async def fourk(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=4k')
      fourkjson = await request.json()

    embed = discord.Embed(title = '4k', description = '\n', color = 0x009933)
    embed.set_image(url=fourkjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()

  @commands.command(aliases=['boob'])
  @commands.is_nsfw()
  async def boobs(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=boobs')
      boobsjson = await request.json()

    embed = discord.Embed(title = 'Boobs', description = '\n', color = 0x996633)
    embed.set_image(url=boobsjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()

  @commands.command()
  @commands.is_nsfw()
  async def pussy(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=pussy')
      pussyjson = await request.json()

    embed = discord.Embed(title = 'Pussy', description = '\n', color = 0x996633)
    embed.set_image(url=pussyjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()

  @commands.command()
  @commands.is_nsfw()
  async def hentai(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=hentai')
      hentaijson = await request.json()

    embed = discord.Embed(title = 'Hentai', description = '\n', color = 0x996633)
    embed.set_image(url=hentaijson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()


  @commands.command()
  @commands.is_nsfw()
  async def futa(self, ctx):
    # n = ['01','02','03','04','05','06','07','08','09']
    random_pic = random.randint(10,76) #or random.choice(n)

    embed = discord.Embed(title = 'Futa', description = '\n', color = 0x996633)
    embed.set_image(url=f'https://cdn.nekos.life/futanari/futanari{random_pic}.jpg')
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()


  @commands.command(aliases=['bj'])
  @commands.is_nsfw()
  async def blowjob(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=blowjob')
      bjjson = await request.json()

    embed = discord.Embed(title = 'Blowjob', description = '\n', color = 0x996633)
    embed.set_image(url=bjjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()


  @commands.command(aliases=['MILF'])
  @commands.is_nsfw()
  async def milf(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://api.waifu.im/nsfw/milf')
      milfjson = await request.json()

    embed = discord.Embed(title = 'MILF', description = '\n', color = 0x996633)
    embed.set_image(url=milfjson['images'][0]['url'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()


  @commands.command(aliases=['GIF'])
  @commands.is_nsfw()
  async def gif(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://api.waifu.im/random/?gif=true')
      gifjson = await request.json()

    embed = discord.Embed(title = 'GIF', description = '\n', color = 0x996633)
    embed.set_image(url=gifjson['images'][0]['url'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()





  @commands.command(aliases=['Anal'])
  @commands.is_nsfw()
  async def anal(self, ctx):
    async with aiohttp.ClientSession() as session:
      request = await session.get('https://nekobot.xyz/api/image?type=anal')
      analjson = await request.json()

    embed = discord.Embed(title = 'Anal', description = '\n', color = 0x009933)
    embed.set_image(url=analjson['message'])
    await ctx.send(embed=embed, delete_after = 10.0)
    await ctx.message.delete()

  

    

    

  





def setup(client):
  client.add_cog(nsfw(client))

    