import discord
from discord.ext import commands
import asyncio
import random
import os


class prefixes(commands.Cog):

  def __init__(self, client):
    self.client = client
    

  @commands.command(name='pre',aliases=['p'])
  @commands.has_permissions(administrator=True)
  async def pre(self, ctx):
    embed = discord.Embed(title='Your Prefix',description=f'You Current Prefix For This Server Is `%`',color=0x0000cc)
    await ctx.send(embed=embed)

  



    
    




def setup(client):
  client.add_cog(prefixes(client))

    