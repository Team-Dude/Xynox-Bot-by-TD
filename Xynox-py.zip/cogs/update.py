import discord
from discord.ext import commands
import asyncio
import random


class update(commands.Cog):

  def __init__(self, client):
    self.client = client


  @commands.command(aliases=['patch','patchnotes','Update','Patch'])
  async def update(self, ctx):
    embed = discord.Embed(title='Patch Notes', description = 'Xynox Patch Notes',color = 0x3366ff)
    embed.add_field(name='G*Y command', value='Some small changes added to gay command ',inline=False)
    embed.add_field(name='TicTacToe', value='The ultimate tictactoe game is here,from using ur custom emojis to winning,we have all covered for u ',inline=False)
    embed.add_field(name='kill and reverse', value='New commands added to xynox. Go use them out rn',inline=False)
    embed.set_footer(text='v2.7')
    embed.set_thumbnail(url='https://media.discordapp.net/attachments/617339888324575232/921011536099684392/xy.png?width=758&height=676')
    await ctx.reply(embed=embed)


def setup(client):
  client.add_cog(update(client))

    