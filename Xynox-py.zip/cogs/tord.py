import discord
from discord.ext import commands
import asyncio
import random
import DiscordUtils

class tord(commands.Cog):

  def __init__(self, client):
    self.client = client


  # @commands.command()
  # @commands.is_owner()
  # async def tord(self, ctx):
  #   truth_items = [(list of truth questions)]
  #   dare_items = [(list of dare questions)]
  #   await ctx.send("please type t for truth and d for dare")
  #   def check(self, message):
  #       return message.author == ctx.author and message.channel == ctx.channel and message.content.lower() in ("t", "d")
  #   message = await bot.wait_for("message", check=check)
  #   choice = message.content.lower()
  #   if choice == "t":
  #       await ctx.send(f"{random.choice(truth_items)}")
  #   if choice == "d":
  #       await ctx.send(f"{random.choice(dare_items)}")




def setup(client):
  client.add_cog(tord(client))

    