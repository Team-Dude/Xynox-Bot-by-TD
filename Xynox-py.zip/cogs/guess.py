import discord
from discord.ext import commands
import asyncio
import random

class guess(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command(aliases=["G","g"])
  async def guess(self, ctx):
    number = random.randint(1,20)
    embed = discord.Embed(title="Guess The Number!", description ="Guess what number between 1 to 20 xynox is thinking....\n\n**Rules:**\n• You have 4 tries\n• The number is between 1 and 20\n• U have 15 sec for each guess",color=0x66ccff )
    embed.add_field(name="Enter The Number below",value="Gud Luck ;)")
    embed.set_image(url="http://static.skaip.org/img/emoticons/180x180/f6fcff/pointdownindex.gif")
    await ctx.send(embed=embed)
    for i in range(0,4):
      response = await self.client.wait_for('message',timeout=15)
      guess = int(response.content)
      if guess > number and guess < 21:
        await ctx.send("Too Big")
      elif guess < number and guess < 21:
        await ctx.send("Too Small")
      elif guess > 20:
        await ctx.send("Out Of Range!!")
      else:
        break

    if guess == number:
      await ctx.send(f"BRAVO!!! U Got It... You Guessed My Number '{number}' was guessed in {i+1} guesses")
    else:
      await ctx.send(f"Srry Kid!, My Number was {number}")

  @guess.error
  async def on_error(self,ctx, error):
    if isinstance (error, commands.CommandInvokeError):
      await ctx.send(embed=discord.Embed(title="TIMEOUT!",description="Time ran out Bruh! Or An Idiot interrupted",color=0x003300))
    

  






def setup(client):
  client.add_cog(guess(client))

    