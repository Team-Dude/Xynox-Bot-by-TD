import discord
from discord.ext import commands
import asyncio
import random
import DiscordUtils

class kill(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.cooldown(rate=1, per=2, type=commands.BucketType.user)
  @commands.command(aliases=["murder", "slay"])
  @commands.bot_has_permissions(embed_links=True)
  @commands.guild_only()
  async def kill(self, ctx, *, user: discord.Member):

      user = user or ctx.author
      kill_msg = [
          f"{user.name} gets stabbed by a knife from {ctx.author.name}",
          f"{user.name} gets shot by {ctx.author.name}",
          f"{user.name} gets executed by {ctx.author.name}",
          f"{user.name} gets impaled by {ctx.author.name}",
          f"{user.name} gets burned by {ctx.author.name}",
          f"{user.name} gets crucified by {ctx.author.name}",
          f"{user.name} was eaten by {ctx.author.name}",
          f"{user.name} died from {ctx.author.name}'s awful puns",
          f"{user.name} was cut in half by {ctx.author.name}",
          f"{user.name} was hanged by {ctx.author.name}",
          f"{user.name} was strangled by {ctx.author.name}",
          f"{user.name}'s pussy was eaten by {ctx.author.name}",
          f"{user.name} died from a poorly made cupcake by {ctx.author.name}",
          f"{user.name} died within a couple seconds of getting jumped by {ctx.author.name}",
          f"{ctx.author.name} 'accidentally' killed {user.name}",
          f"{ctx.author.name} tried to kill {user.name}, but just missed",
          f"{ctx.author.name} tried to strangle {user.name}, but it didn't work",
          f"{ctx.author.name} tripped over their own knife trying to kill {user.name} but killed themselves instead!",
      ]
      if user == ctx.author:
          embed = discord.Embed(
              title=f"Okay you've killed yourself {ctx.author.name}, I hope this was worth it! Now tag someone else to kill them!",
              colour=0x330000,
              timestamp=f'Incident occured {ctx.message.created_at}',
              icon_url=ctx.author.avatar,
          )
          embed.set_image(url='https://c.tenor.com/MRyVTolUn9YAAAAC/homer-hang.gif')

          await ctx.send(embed=embed)
      else:
          embed = discord.Embed(
              title=f"{random.choice(kill_msg)}",
              colour=0x990000,
              timestamp=ctx.message.created_at,
              icon_url=ctx.author.avatar,
          )
          await ctx.send(embed=embed)

def setup(client):
  client.add_cog(kill(client))
