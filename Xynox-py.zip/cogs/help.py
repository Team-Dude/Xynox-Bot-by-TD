import discord
from discord.ext import commands
import asyncio
import random
import DiscordUtils

class help(commands.Cog):

  def __init__(self, client):
    self.client = client


  @commands.command()
  @commands.is_owner()
  async def help2(self, ctx):
      embed1 = discord.Embed(color=0x33cc33).add_field(name="Xynox's Help Center is here to provide u aid in every aspect... \n\n**Moderation**", value="[kick](https://basitshahidhamid.wixsite.com/xynox/commands)\n\tkicks the member from the server\n\n[purge](https://basitshahidhamid.wixsite.com/xynox/commands)\nclear x number of messages\n\n[voicemove](https://basitshahidhamid.wixsite.com/xynox/commands)\n\tMove a user to diff vc.")
      embed2 = discord.Embed(color=0x0000cc).add_field(name="**Fun**", value="[8ball](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tAsk the magic 8ball about your future!\n\n[hy](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tSay Hiiiii to Xynox\n\n[slap](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tSlap that bi*ch\n\n[insult](Disrespectfull!!!)\n\n[poop](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tShit. Literally!!\n\n[dark](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tDark jokes galore\n\n[waifu](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tFind out how much waifu u r!\n\n[nitro](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tOur free nitro giveaway is ending soon. Claim it b4 it ends!\n\n[meme](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tSends a refreshing meme\n\n[pp](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tInstead of measuring ,find ur pp size using this command.\n\n[gayrate](https://basitshahidhamid.wixsite.com/xynox/fun-commands)\n\tHow much gay u r?")
      embed3 = discord.Embed(color=0x99ffcc).add_field(name="**Games**", value="[rps](https://basitshahidhamid.wixsite.com/xynox/games-commands)\n\tPlay the game of rock,papers,scissors. Guns not allowed!\n\n[slot](https://basitshahidhamid.wixsite.com/xynox/games-commands)\n\tMatch 3 and win.Simple!\n\n[crush](https://basitshahidhamid.wixsite.com/xynox/games-commands)\n\tFind out your crush .Keep it Secret...\n\n[wyr](https://basitshahidhamid.wixsite.com/xynox/games-commands)\n\tHard af would u rather game....\n\n[cric play](https://basitshahidhamid.wixsite.com/xynox/games-commands)\n\tRelive the og days by playing exclusive hand cricket game.")
      embed4 = discord.Embed(color=0x663300).add_field(name="**NSFW**",value="[nsfw](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nGet the list of all nsfw commands\n\n[4k](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nHigh Quality Pleasure\n\n[ass](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nThiCCC booties!\n\n[anal](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nAnal-lyze\n\n[boobs](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nBoobiees!!\n\n[pussy](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nMeow!!\n\n[hentai](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nDive into hentai multiverse\n\n[futa](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nFuta eh..\n\n[Blowjob](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nFk yeah!!\n\n[GIF](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nGet animated porn\n\n[MILF](https://basitshahidhamid.wixsite.com/xynox/nsfw)\nMilfs but anime. ")
      paginator = DiscordUtils.Pagination.CustomEmbedPaginator(ctx, remove_reactions=True)
      paginator.add_reaction('⏮️', "first")
      paginator.add_reaction('⏪', "back")
      paginator.add_reaction('🔐', "lock")
      paginator.add_reaction('⏩', "next")
      paginator.add_reaction('⏭️', "last")
      embeds = [embed1, embed2, embed3, embed4]
      await paginator.run(embeds)
    



def setup(client):
  client.add_cog(help(client))

    