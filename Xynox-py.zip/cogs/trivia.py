import discord
from discord.ext import commands
import asyncio
import requests
import random
import DiscordUtils

class trivia(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command(aliases=['trivia','Fact','Facts','Trivia'])
  async def facts(self,ctx): 

    url = "https://trivia-by-api-ninjas.p.rapidapi.com/v1/trivia"

    headers = {
        'x-rapidapi-host': "trivia-by-api-ninjas.p.rapidapi.com",
        'x-rapidapi-key': "2e052e1015mshb9e9027e2def188p17d478jsn0c14295263a3"
        }


    response = requests.request("GET", url, headers=headers)

    await ctx.send(response)



def setup(client):
  client.add_cog(trivia(client))

    